# This is package documentation for wildlifeTG.
# roxygen will use this file to create a NAMESPACE file.
# Of importance is the @import command, as it lists package dependencies.

#' wildlifeTG - Time Geographic Analysis of Wildlife Telemetry Data
#'
#' The Package \code{wildlifeTG} provides tools for performing dynamic time geographic analysis of animal 
#' tracking data. The functions provide useful tools for examining movement accessibility...
#'
#' \code{wildlifeTG}'s functions utilize the \code{ltraj} objects from the package \code{adehabitat}. 
#'
#' @author Jed Long
#' @references
#' Long, JA, Nelson, TA. (2012) Time geography and wildlife home range delineation. \emph{Journal of Wildlife
#'   Management}, 76(2):407-413.\cr
#'
#' @import sp adehabitatLT rgeos
#' @docType package
#' @name wildlifeTG-package
NULL
