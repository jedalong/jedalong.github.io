# ---- roxygen documentation ----
#' @title Joint Activity Space (Dynamic PPA Home Range)
#'
#' @description
#'   The function \code{jDynPPAHR} computes the joint activity space between two animals. It can be used
#'   to delineate that area jointly accessible to two individual animals in space ant time.
#' @details
#'   The function \code{jDynPPAHR} can be used to map areas of potential interaction between two animals.
#'   Specifically, this represents a measure of spatial overlap that also considers the temporal sequencing 
#'   telemetry point. In this respect it improves significantly over static measures of home range overlap, 
#'   often used to measure static interaction.
#'
#' @param traj1 an object of the class \code{ltraj} which contains the time-stamped
#'    movement fixes of the first object. Note this object must be a \code{type II
#'    ltraj} object. For more information on objects of this type see \code{
#'    help(ltraj)}.
#' @param traj2 same as \code{traj1}.
#' @param t.int (optional) time parameter (in seconds) used to determine the frequency of time slices 
#'    used to delineate the joint activity space. Default is 1/10th of the mode of the temporal sampling
#'    interval from \code{traj1}. Smaller values for \code{t.int} will result in smoother output polygons.
#' @param tol (optional) parameter used to filter out those segments where the time between fixes is overly 
#'    large (often due to irregular sampling or missing fixes); which leads to an overestimation of the 
#'    activity space via the PPA method. Default is the maximum sampling interval from \code{traj1}.
#' @param vmaxtrunc (optional) Due to irregular sampling intervals, or errors in GPS location, or other
#'    effects, the calculation of the Vmax parameter through the statistical methods outlined above can be
#'    heavily influenced by high outliers. Thus, it may be useful to exclude those segments from calculation 
#'    of the dynamic Vmax parameter. Default is \code{NA}.
#' @param dissolve logical parameter indicating whether (\code{=TRUE}; the default) or not (\code{=FALSE})
#'    to return a spatially dissolved polygon of the joint activity space.
#' @param ePoints number of vertices used to construct each PPA ellipse. More points will necessarily provide
#'    a more detailed ellipse shape, but will slow computation; default is 360.
#' @param ... additional parameters to be passed to the function \code{DynVmax}. For example, should include
#'    \code{method}; see the documentation for \code{DynVmax} for more detailed
#'    information on what to include here.
#'    
#' @return
#'   This function returns a \code{SpatialPolygonsDataFrame} representing the joint activity space between
#'   the two animals.
#'
# @references
# @keywords 
#' @seealso dyn.vmax, dyn.ppa.hr
# @examples
#' 
#' @export
#
# ---- End of roxygen documentation ----
##Function for computing interaction range
jDynPPAHR <- function(traj1,
                      traj2,
                      t.int=0.1*as.numeric(names(sort(-table(ld(traj1)$dt)))[1]),
                      tol=max(ld(traj1)$dt,na.rm=T), 
                      vmaxtrunc=NA, 
                      dissolve = TRUE, 
                      ePoints=360, 
                      ...){
  
  #EXTRA FUNCTIONS
  #====================================================================================  
  # Function get.anchors, gets two trajectory points surrounding a time point.
  get.anchors <- function(traj,t.slice){
    indF <- max(which(difftime(traj$date,t.slice) <= 0))     #Forward anchor index
    indP <- min(which(difftime(traj$date,t.slice) >= 0))     #Past anchor index
    pF <- traj[indF,c('x','y','date','dynVmax','dt','vRaw')]
    pP <- traj[indP,c('x','y','date','dynVmax','dt','vRaw')]
    ret <- rbind(pF,pP)
    ret$ind <- c(indF,indP)
    return(ret)
  }
  #function for identifying the prism slice instersection polygon
  prism.slice.int <- function(t,a1,a2,tol,vmaxtrunc,ePoints){
    
    p1 <- prism.slice(a1,t,tol,vmaxtrunc,ePoints)
    p2 <- prism.slice(a2,t,tol,vmaxtrunc,ePoints)
    #prism slice intersection
    if (!is.null(p1) & !is.null(p2)) {
      pInt <- gIntersection(p1,p2,id=as.character(t))
      if (!is.null(pInt)) {
        jppa <- slot(pInt,'polygons')
        return(jppa)
      } else {return(NULL)}
    } else {return(NULL)}
  }
  
  # Function prism.slice computes the ST prism polygon slice for a given time point.
  prism.slice <- function(anchors,t.slice,tol,vmaxtrunc,ePoints){
    if (anchors[1,'dt'] > tol || is.na(anchors[1,'dynVmax']) || is.na(anchors[1,'dt'])){return(NULL)}
    else{
      #vmax always associated with the forward point due to how it is defined for segment.
      if (anchors[1,'vRaw'] <= vmaxtrunc){
        vmax <- anchors[1,'dynVmax']
      } else {
        vmax <- anchors[1,'vRaw']*1.05
      }
      #the number of points around the circle
      theta <- seq(0,2*pi,length.out=ePoints)
      #calculate the radius of the Future Cone
      tF <- difftime(t.slice,anchors[1,3],units="secs")
      rF <- vmax*tF  #vmax is anchors[1,4]
      #calculate the radius of the Past Cone
      tP <- difftime(anchors[2,3],t.slice,units="secs")
      rP <- vmax*tP
      #get x,y coords of Future Cone circle
      x1 <- anchors[1,1] + rF*cos(theta)
      y1 <- anchors[1,2] + rF*sin(theta)
      #get x,y coords of Past Cone circle
      x2 <- anchors[2,1] + rP*cos(theta)
      y2 <- anchors[2,2] + rP*sin(theta)
      #create spatial polygons and intersect them
      c1 <- Polygon(rbind(cbind(x1,y1),c(x1[1],y1[1])))
      c2 <- Polygon(rbind(cbind(x2,y2),c(x2[1],y2[1])))
      spc1 <- SpatialPolygons(list(Polygons(list(c1),ID="1")))
      spc2 <- SpatialPolygons(list(Polygons(list(c2),ID="2")))
      slicePoly <- gIntersection(spc1,spc2) 
      return(slicePoly)
    }
  }
  #===========================================================================
  
  traj1 <- dyn.vmax(traj1,...)
  traj2 <- dyn.vmax(traj2,...)
  tr1 <- ld(traj1)
  tr2 <- ld(traj1)
  
  n <- dim(tr1)[1]
  tr1$vRaw <- c(tr1$dist[1:(n-1)] / tr1$dt[1:(n-1)],NA)
  n <- dim(tr2)[1]
  tr2$vRaw <- c(tr2$dist[1:(n-1)] / tr2$dt[1:(n-1)],NA)
  if (is.na(vmaxtrunc)){
    vmaxtrunc<-max(c(tr1$vRaw,tr2$vRaw),na.rm=T)
  } 

  t.start <- max(c(min(tr1$date),min(tr2$date)))
  t.end <- min(c(max(tr1$date),max(tr2$date)))
  tt <- seq(t.start+t.int, t.end, by=t.int,)
  if (t.int < 0){stop(paste('Time interval is too small: ',t.int))}
  
  a1 <- lapply(tt,get.anchors,traj=tr1)
  a2 <- lapply(tt,get.anchors,traj=tr2)
  
#   poly.list <- vector('list',length(tt))
#   for (i  in 1:length(tt)){
#     a1 <- get.anchors(tr1,tt[i])
#     a2 <- get.anchors(tr2,tt[i])
#     poly.list[[i]] <- prism.slice.int(tt[i],a1,a2,tol=tol,vmaxtrunc=vmaxtrunc,ePoints=ePoints)
#   }
  
  pol.list <- mapply(prism.slice.int,tt,a1,a2,MoreArgs=list(tol=tol,vmaxtrunc=vmaxtrunc,ePoints=ePoints))
  #print(paste('length polys list:',length(polys.list)))
  ind <- which(sapply(pol.list,is.null,simplify=TRUE,USE.NAMES=FALSE)==FALSE)
  if (length(ind)==0){
    return(NULL)
  } else {
    timeVar = tt[ind]
    data <- data.frame(DateTime = timeVar)
    #rownames(data) <- as.character(1:length(ind))
    poly.list <- unlist(pol.list[ind])
    spdf <- SpatialPolygonsDataFrame(SpatialPolygons(poly.list),data=data,match.ID=F)
    spdf.diss <- gUnaryUnion(spdf)
    spdf.diss2 <- SpatialPolygonsDataFrame(spdf.diss,data=data.frame(id=1:length(spdf.diss)),match.ID=F)
    if (dissolve == TRUE){
      return(spdf.diss2)
    } else {
      return(spdf)
    }
  }
}

#=====================================================================