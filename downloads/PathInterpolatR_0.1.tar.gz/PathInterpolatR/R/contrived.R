#' Contrived example dataset
#'
#' A dataset pertaining to the contrived example from Long (2015) used to demonstrate each method for path interpolation.
#' 
#' Contrived example dataset for contrasting different path interpolation methods (open circles) with kinematic interpolation (grey crosses). In the contrived example, the object begins at the point z(0) = (0,-3) with a velocity of 0 m/s and then moves to the origin z(1) = (0, 0) with a velocity of 3 m/s to the North v(1) = (0,3). The object reaches position z(6) = (10,10) after 5 s, it now has a velocity of 3 m/s to the East v(6) = (3,0) and it continues on to location z(7) = (13,10). The time difference between the second and thrid point is 5 s and the object's location is estimated every 0.5 s in between. 
#'
#' @references
#' Long, JA (2015) Kinematic interpolation of movement data. \emph{International Journal of Geographical Information Science}. DOI: 10.1080/13658816.2015.1081909. 
#' @name contrived  
#' @docType data
#' @keywords datasets
#' @format A dataframe (\code{contrived}) delineating the four anchor points for path interpolation from the contrived example in Long (2015). 
NULL
